# TaskMaster AI - Development Guide

## Overview

TaskMaster AI is an AI-powered internal task management system designed exclusively for HolidayTribe employees. The application enables natural language-based task assignment, tracking, and reporting with minimal manual UI interactions.

**Current Status**: Application fully operational with MongoDB Atlas backend, email service, and all TypeScript errors resolved. Complete authentication and task management system working.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (January 24, 2025)

✓ **Database Migration**: Successfully migrated from PostgreSQL/Drizzle to MongoDB Atlas
✓ **Schema Update**: Converted Drizzle schema to Mongoose models with proper document relationships  
✓ **Storage Layer**: Rebuilt storage interface for MongoDB operations (users, tasks, comments, reports, OTP)
✓ **Dependencies**: Updated package.json to use MongoDB/Mongoose instead of PostgreSQL libraries
✓ **Connection**: Established MongoDB Atlas connection with provided URI
✓ **Email Service**: Configured SMTP credentials for OTP delivery and report emails
✓ **TypeScript Errors**: Fixed all MongoDB ID type casting issues in routes for production readiness
✓ **Testing**: Verified OTP email delivery and database operations working correctly

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS with shadcn/ui component library
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for lightweight client-side routing
- **Build Tool**: Vite for fast development and building
- **UI Components**: Radix UI primitives with custom styling

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Database ODM**: Mongoose for MongoDB document operations  
- **Database**: MongoDB Atlas (cloud-hosted with replica sets)
- **Authentication**: JWT-based with OTP email verification
- **AI Integration**: OpenAI GPT-4o for natural language processing
- **Email Service**: Nodemailer for OTP and report delivery

### Key Components

#### Authentication System
- **OTP-based login**: Email verification using 6-digit codes
- **Role-based access**: Admin, Manager, and IC (Individual Contributor) roles
- **Session management**: JWT tokens with 24-hour expiration
- **Email validation**: Restricted to @holidaytribe.com domain

#### AI-Powered Interface
- **Natural language parsing**: Converts user prompts into structured actions
- **Task operations**: Create, update, query, and report generation via prompts
- **Intelligent suggestions**: Context-aware task recommendations
- **Report generation**: Automated daily, weekly, and stakeholder reports

#### Task Management
- **Status tracking**: todo, in_progress, blocked, in_review, done
- **Priority levels**: low, medium, high, critical
- **Progress monitoring**: Percentage-based completion tracking
- **Due date management**: Automated overdue detection
- **Tag system**: Flexible categorization
- **Comments**: Threaded discussions on tasks

#### Organizational Structure
- **Hierarchical management**: Manager-reportee relationships
- **Team visibility**: Managers can view all team member tasks
- **Workload distribution**: Visual workload charts and analytics
- **Cross-team collaboration**: Task assignment across teams

### Data Flow

1. **User Authentication**: OTP request → Email delivery → Token verification → JWT issuance
2. **AI Prompt Processing**: Natural language input → OpenAI parsing → Structured action → Database operation
3. **Task Operations**: CRUD operations through REST API with real-time updates
4. **Report Generation**: AI-powered content creation → Email delivery → Storage for history
5. **Team Analytics**: Aggregated task data → Visual dashboards → Management insights

### External Dependencies

#### AI Services
- **OpenAI API**: GPT-4o for natural language processing and report generation
- **API Key Management**: Environment variable configuration

#### Database
- **MongoDB Atlas**: Cloud-hosted MongoDB with authentication and replication
- **Schema Management**: Mongoose ODM for document modeling and validation

#### Email Services
- **SMTP Configuration**: Gmail or custom SMTP for OTP and notifications
- **Template System**: HTML email templates for professional communication

#### UI Libraries
- **Radix UI**: Accessible component primitives
- **Lucide Icons**: Consistent icon system
- **Date-fns**: Date manipulation and formatting

### Deployment Strategy

#### Development Environment
- **Vite Dev Server**: Hot module replacement for frontend
- **Express Server**: API development with auto-restart
- **Database**: Direct connection to Neon PostgreSQL
- **Environment Variables**: Local .env file configuration

#### Production Build
- **Frontend**: Vite build to static assets
- **Backend**: ESBuild compilation to single JS file
- **Static Serving**: Express serves built frontend
- **Process Management**: Single Node.js process

#### Environment Configuration
- **Database**: MongoDB URI for Atlas connection
- **AI**: OPENAI_API_KEY for GPT-4o access
- **Email**: SMTP credentials for email delivery
- **Security**: JWT_SECRET for token signing

#### Scaling Considerations
- **Database**: MongoDB Atlas auto-scaling and sharding
- **File Storage**: Static assets served from dist/public
- **Session Storage**: Stateless JWT tokens
- **API Rate Limiting**: Configurable via middleware