import mongoose, { Schema, Document } from 'mongoose';
import { z } from 'zod';

// Enums
export const RoleEnum = ['admin', 'manager', 'ic'] as const;
export const StatusEnum = ['todo', 'in_progress', 'blocked', 'in_review', 'done'] as const;
export const PriorityEnum = ['low', 'medium', 'high', 'critical'] as const;

// Interface definitions
export interface IUser extends Document {
  email: string;
  username: string;
  firstName: string;
  lastName: string;
  role: typeof RoleEnum[number];
  managerId?: mongoose.Types.ObjectId;
  isActive: boolean;
  lastLogin?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface ITask extends Document {
  title: string;
  description?: string;
  status: typeof StatusEnum[number];
  priority: typeof PriorityEnum[number];
  progress: number;
  assigneeId: mongoose.Types.ObjectId;
  createdById: mongoose.Types.ObjectId;
  dueDate?: Date;
  completedAt?: Date;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

export interface IComment extends Document {
  taskId: mongoose.Types.ObjectId;
  userId: mongoose.Types.ObjectId;
  content: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface IOTP extends Document {
  email: string;
  code: string;
  expiresAt: Date;
  used: boolean;
  createdAt: Date;
}

export interface IReport extends Document {
  title: string;
  content: string;
  type: string;
  recipientEmail: string;
  generatedById: mongoose.Types.ObjectId;
  sentAt?: Date;
  createdAt: Date;
}

// Mongoose Schemas
const userSchema = new Schema<IUser>({
  email: { type: String, required: true, unique: true },
  username: { type: String, required: true, unique: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  role: { type: String, enum: RoleEnum, default: 'ic' },
  managerId: { type: Schema.Types.ObjectId, ref: 'User' },
  isActive: { type: Boolean, default: true },
  lastLogin: { type: Date },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const taskSchema = new Schema<ITask>({
  title: { type: String, required: true },
  description: { type: String },
  status: { type: String, enum: StatusEnum, default: 'todo' },
  priority: { type: String, enum: PriorityEnum, default: 'medium' },
  progress: { type: Number, default: 0, min: 0, max: 100 },
  assigneeId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  createdById: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  dueDate: { type: Date },
  completedAt: { type: Date },
  tags: [{ type: String }],
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const commentSchema = new Schema<IComment>({
  taskId: { type: Schema.Types.ObjectId, ref: 'Task', required: true },
  userId: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  content: { type: String, required: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const otpSchema = new Schema<IOTP>({
  email: { type: String, required: true },
  code: { type: String, required: true },
  expiresAt: { type: Date, required: true },
  used: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
});

const reportSchema = new Schema<IReport>({
  title: { type: String, required: true },
  content: { type: String, required: true },
  type: { type: String, required: true },
  recipientEmail: { type: String, required: true },
  generatedById: { type: Schema.Types.ObjectId, ref: 'User', required: true },
  sentAt: { type: Date },
  createdAt: { type: Date, default: Date.now }
});

// Models
export const User = mongoose.model<IUser>('User', userSchema);
export const Task = mongoose.model<ITask>('Task', taskSchema);
export const Comment = mongoose.model<IComment>('Comment', commentSchema);
export const OTP = mongoose.model<IOTP>('OTP', otpSchema);
export const Report = mongoose.model<IReport>('Report', reportSchema);

// Zod schemas for validation
export const insertUserSchema = z.object({
  email: z.string().email(),
  username: z.string().min(1),
  firstName: z.string().min(1),
  lastName: z.string().min(1),
  role: z.enum(RoleEnum).default('ic'),
  managerId: z.string().optional(),
  isActive: z.boolean().default(true)
});

export const insertTaskSchema = z.object({
  title: z.string().min(1),
  description: z.string().optional(),
  status: z.enum(StatusEnum).default('todo'),
  priority: z.enum(PriorityEnum).default('medium'),
  progress: z.number().min(0).max(100).default(0),
  assigneeId: z.string(),
  createdById: z.string(),
  dueDate: z.string().optional(),
  tags: z.array(z.string()).default([])
});

export const insertCommentSchema = z.object({
  taskId: z.string(),
  userId: z.string(),
  content: z.string().min(1)
});

export const insertOTPSchema = z.object({
  email: z.string().email(),
  code: z.string().length(6),
  expiresAt: z.string()
});

export const insertReportSchema = z.object({
  title: z.string().min(1),
  content: z.string().min(1),
  type: z.string(),
  recipientEmail: z.string().email(),
  generatedById: z.string()
});

// Type exports
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type InsertComment = z.infer<typeof insertCommentSchema>;
export type InsertOTP = z.infer<typeof insertOTPSchema>;
export type InsertReport = z.infer<typeof insertReportSchema>;