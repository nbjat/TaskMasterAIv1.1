import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { getAuthHeaders } from "@/lib/auth";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import ReportGenerator from "@/components/reports/report-generator";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { FileText, Download, Mail, Calendar, User, BarChart3, Clock } from "lucide-react";
import { format, subDays, subWeeks } from "date-fns";

export default function Reports() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedReportType, setSelectedReportType] = useState<'daily' | 'weekly' | 'stakeholder'>('weekly');
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [dateRange, setDateRange] = useState({
    start: format(subWeeks(new Date(), 1), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd'),
  });

  // Fetch team members for report selection
  const { data: teamMembers } = useQuery({
    queryKey: ['/api/users/team'],
    queryFn: async () => {
      const response = await fetch('/api/users/team', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: user?.role === 'manager' || user?.role === 'admin',
  });

  // Fetch user's previous reports
  const { data: previousReports } = useQuery({
    queryKey: ['/api/reports', user?.id],
    queryFn: async () => {
      const response = await fetch(`/api/reports?userId=${user?.id}`, {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
  });

  const generateReportMutation = useMutation({
    mutationFn: async (params: {
      type: 'daily' | 'weekly' | 'stakeholder';
      userId?: number;
      startDate: string;
      endDate: string;
      emailTo?: string;
    }) => {
      const response = await apiRequest('POST', '/api/reports/generate', params);
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Report Generated",
        description: "Your report has been generated successfully",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive",
      });
    },
  });

  const handleGenerateReport = (params: {
    type: 'daily' | 'weekly' | 'stakeholder';
    userId?: number;
    emailTo?: string;
  }) => {
    generateReportMutation.mutate({
      ...params,
      startDate: dateRange.start,
      endDate: dateRange.end,
    });
  };

  const quickReports = [
    {
      title: "My Daily Report",
      description: "Today's task summary and progress",
      type: 'daily' as const,
      icon: Calendar,
      color: "text-blue-600",
      bgColor: "bg-blue-50",
    },
    {
      title: "My Weekly Report",
      description: "Weekly accomplishments and upcoming work",
      type: 'weekly' as const,
      icon: BarChart3,
      color: "text-green-600",
      bgColor: "bg-green-50",
    },
    {
      title: "Team Summary",
      description: "Team performance and workload overview",
      type: 'stakeholder' as const,
      icon: User,
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      requiresManager: true,
    },
  ];

  const availableUsers = [
    ...(user ? [{ id: user.id, name: 'Myself', email: user.email }] : []),
    ...(teamMembers || []),
  ];

  return (
    <>
      <Header 
        title="Reports" 
        description="Generate AI-powered reports and insights"
      />

      <main className="flex-1 p-6 overflow-auto">
        <Tabs defaultValue="generate" className="space-y-6">
          <TabsList>
            <TabsTrigger value="generate">Generate Report</TabsTrigger>
            <TabsTrigger value="history">Report History</TabsTrigger>
          </TabsList>

          <TabsContent value="generate" className="space-y-6">
            {/* Quick Report Actions */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {quickReports.map((report, index) => {
                if (report.requiresManager && user?.role === 'ic') return null;
                
                return (
                  <Card key={index} className="border border-gray-200 hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className={`w-12 h-12 rounded-lg ${report.bgColor} flex items-center justify-center mb-4`}>
                        <report.icon className={`w-6 h-6 ${report.color}`} />
                      </div>
                      <h3 className="font-semibold text-gray-900 mb-2">{report.title}</h3>
                      <p className="text-sm text-gray-600 mb-4">{report.description}</p>
                      <Button
                        size="sm"
                        onClick={() => handleGenerateReport({ 
                          type: report.type,
                          userId: user?.id 
                        })}
                        disabled={generateReportMutation.isPending}
                        className="w-full"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Generate Report
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Custom Report Generator */}
            <ReportGenerator
              onGenerate={handleGenerateReport}
              teamMembers={availableUsers}
              isLoading={generateReportMutation.isPending}
            />

            {/* Generated Report Display */}
            {generateReportMutation.data && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>Generated Report</span>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Download className="w-4 h-4 mr-2" />
                        Download
                      </Button>
                      <Button variant="outline" size="sm">
                        <Mail className="w-4 h-4 mr-2" />
                        Email
                      </Button>
                    </div>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="bg-gray-50 rounded-lg p-6">
                    <pre className="whitespace-pre-wrap text-sm text-gray-800 font-mono">
                      {generateReportMutation.data.content}
                    </pre>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Report History</CardTitle>
              </CardHeader>
              <CardContent>
                {previousReports && previousReports.length > 0 ? (
                  <div className="space-y-4">
                    {previousReports.map((report: any) => (
                      <div key={report.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                            <FileText className="w-5 h-5 text-primary" />
                          </div>
                          <div>
                            <p className="font-medium text-gray-900">
                              {report.generatedBy === 'ai' ? 'AI Generated Report' : 'Manual Report'}
                            </p>
                            <p className="text-sm text-gray-500">
                              Generated on {format(new Date(report.createdAt), 'MMM d, yyyy at h:mm a')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">
                            {report.generatedBy}
                          </Badge>
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <FileText className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No reports generated yet.</p>
                    <p className="text-sm text-gray-400 mt-1">Generate your first report to see it here.</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}
