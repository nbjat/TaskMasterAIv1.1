import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAuthHeaders, hasRole } from "@/lib/auth";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import TaskCard from "@/components/tasks/task-card";
import TaskModal from "@/components/tasks/task-modal";
import WorkloadChart from "@/components/team/workload-chart";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, BarChart3, Clock, AlertTriangle, CheckCircle } from "lucide-react";
import { format } from "date-fns";

export default function Team() {
  const { user } = useAuth();
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<number | undefined>();
  const [selectedMember, setSelectedMember] = useState<string>('all');

  // Fetch team members
  const { data: teamMembers } = useQuery({
    queryKey: ['/api/users/team'],
    queryFn: async () => {
      const response = await fetch('/api/users/team', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: hasRole(user?.role || '', ['manager', 'admin']),
  });

  // Fetch team tasks
  const { data: teamTasks } = useQuery({
    queryKey: ['/api/tasks', 'team', selectedMember],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (selectedMember !== 'all') {
        params.append('assigneeId', selectedMember);
      }
      params.append('managerId', user?.id.toString() || '');
      
      const response = await fetch(`/api/tasks?${params}`, {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: hasRole(user?.role || '', ['manager', 'admin']),
  });

  // Fetch team stats
  const { data: teamStats } = useQuery({
    queryKey: ['/api/analytics/stats', 'team'],
    queryFn: async () => {
      const response = await fetch('/api/analytics/stats', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: hasRole(user?.role || '', ['manager', 'admin']),
  });

  if (!hasRole(user?.role || '', ['manager', 'admin'])) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Card>
          <CardContent className="p-8 text-center">
            <AlertTriangle className="w-12 h-12 text-warning mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600">You need manager or admin privileges to view team data.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getWorkloadLevel = (taskCount: number) => {
    if (taskCount >= 8) return { level: 'High', color: 'bg-red-500' };
    if (taskCount >= 5) return { level: 'Medium', color: 'bg-yellow-500' };
    return { level: 'Low', color: 'bg-green-500' };
  };

  const handleTaskClick = (taskId: number) => {
    setSelectedTask(taskId);
    setTaskModalOpen(true);
  };

  const handleNewTask = () => {
    setSelectedTask(undefined);
    setTaskModalOpen(true);
  };

  const filteredTasks = teamTasks?.filter((task: any) => 
    selectedMember === 'all' || task.assigneeId.toString() === selectedMember
  ) || [];

  return (
    <>
      <Header 
        title="Team View" 
        description="Monitor and manage your team's tasks and workload"
        onNewTask={handleNewTask}
      />

      <main className="flex-1 p-6 overflow-auto">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="workload">Workload</TabsTrigger>
            <TabsTrigger value="tasks">Tasks</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Team Stats */}
            {teamStats && (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Team Tasks</p>
                        <p className="text-3xl font-bold text-gray-900">{teamStats.total}</p>
                      </div>
                      <Users className="w-8 h-8 text-primary" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">In Progress</p>
                        <p className="text-3xl font-bold text-gray-900">{teamStats.inProgress}</p>
                      </div>
                      <Clock className="w-8 h-8 text-warning" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Completed</p>
                        <p className="text-3xl font-bold text-gray-900">{teamStats.completed}</p>
                      </div>
                      <CheckCircle className="w-8 h-8 text-success" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="text-sm font-medium text-gray-600">Overdue</p>
                        <p className="text-3xl font-bold text-gray-900">{teamStats.overdue}</p>
                      </div>
                      <AlertTriangle className="w-8 h-8 text-destructive" />
                    </div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Team Members */}
            <Card>
              <CardHeader>
                <CardTitle>Team Members</CardTitle>
              </CardHeader>
              <CardContent>
                {teamMembers && teamMembers.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {teamMembers.map((member: any) => {
                      const memberTasks = teamTasks?.filter((task: any) => task.assigneeId === member.id) || [];
                      const workload = getWorkloadLevel(memberTasks.length);
                      
                      return (
                        <Card key={member.id} className="border border-gray-200">
                          <CardContent className="p-4">
                            <div className="flex items-center space-x-3">
                              <Avatar className="w-12 h-12">
                                <AvatarFallback className="bg-primary text-white">
                                  {getInitials(member.name)}
                                </AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <p className="font-medium text-gray-900 truncate">{member.name}</p>
                                <p className="text-sm text-gray-500">{member.email}</p>
                                <div className="flex items-center space-x-2 mt-2">
                                  <Badge variant="outline" className="text-xs">
                                    {memberTasks.length} tasks
                                  </Badge>
                                  <div className="flex items-center space-x-1">
                                    <div className={`w-2 h-2 rounded-full ${workload.color}`}></div>
                                    <span className="text-xs text-gray-600">{workload.level}</span>
                                  </div>
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <p className="text-gray-500">No team members found.</p>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workload" className="space-y-6">
            <WorkloadChart 
              teamMembers={teamMembers || []} 
              tasks={teamTasks || []} 
            />
          </TabsContent>

          <TabsContent value="tasks" className="space-y-6">
            {/* Task Filters */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-4">
                  <Select value={selectedMember} onValueChange={setSelectedMember}>
                    <SelectTrigger className="w-[200px]">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Team Members</SelectItem>
                      {teamMembers?.map((member: any) => (
                        <SelectItem key={member.id} value={member.id.toString()}>
                          {member.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </CardContent>
            </Card>

            {/* Tasks Grid */}
            {filteredTasks.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredTasks.map((task: any) => (
                  <TaskCard
                    key={task.id}
                    task={task}
                    onClick={() => handleTaskClick(task.id)}
                  />
                ))}
              </div>
            ) : (
              <Card>
                <CardContent className="p-12 text-center">
                  <p className="text-gray-500">No tasks found for the selected criteria.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <TaskModal
        isOpen={taskModalOpen}
        onClose={() => setTaskModalOpen(false)}
        taskId={selectedTask}
        mode={selectedTask ? 'edit' : 'create'}
      />
    </>
  );
}
