import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAuthHeaders, hasRole } from "@/lib/auth";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import OrgChart from "@/components/admin/org-chart";
import UserManagement from "@/components/admin/user-management";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle, Users, Shield, Activity, Database } from "lucide-react";

export default function Admin() {
  const { user } = useAuth();

  // Fetch system stats
  const { data: systemStats } = useQuery({
    queryKey: ['/api/admin/stats'],
    queryFn: async () => {
      const response = await fetch('/api/admin/stats', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: hasRole(user?.role || '', ['admin']),
  });

  // Fetch all users
  const { data: allUsers } = useQuery({
    queryKey: ['/api/users'],
    queryFn: async () => {
      const response = await fetch('/api/users', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
    enabled: hasRole(user?.role || '', ['admin']),
  });

  if (!hasRole(user?.role || '', ['admin'])) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <Card>
          <CardContent className="p-8 text-center">
            <Shield className="w-12 h-12 text-warning mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-gray-600">You need administrator privileges to access this panel.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  const roleStats = allUsers?.reduce((acc: any, user: any) => {
    acc[user.role] = (acc[user.role] || 0) + 1;
    return acc;
  }, {}) || {};

  return (
    <>
      <Header 
        title="Admin Panel" 
        description="Manage organization, users, and system settings"
      />

      <main className="flex-1 p-6 overflow-auto">
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="organization">Organization</TabsTrigger>
            <TabsTrigger value="system">System</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* System Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Users</p>
                      <p className="text-3xl font-bold text-gray-900">{allUsers?.length || 0}</p>
                    </div>
                    <Users className="w-8 h-8 text-primary" />
                  </div>
                  <div className="mt-4 space-y-1">
                    {Object.entries(roleStats).map(([role, count]) => (
                      <div key={role} className="flex items-center justify-between text-sm">
                        <span className="text-gray-600 capitalize">{role}s:</span>
                        <Badge variant="outline" className="text-xs">{count as number}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Active Sessions</p>
                      <p className="text-3xl font-bold text-gray-900">12</p>
                    </div>
                    <Activity className="w-8 h-8 text-success" />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">Users currently online</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">System Health</p>
                      <p className="text-3xl font-bold text-success">Good</p>
                    </div>
                    <Database className="w-8 h-8 text-success" />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">All services operational</p>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Issues</p>
                      <p className="text-3xl font-bold text-gray-900">0</p>
                    </div>
                    <AlertTriangle className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">No critical issues</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Admin Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">User role updated</p>
                      <p className="text-xs text-gray-500">John Doe promoted to Manager - 2 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">New user registered</p>
                      <p className="text-xs text-gray-500">sarah.chen@holidaytribe.com joined - 5 hours ago</p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                    <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">Organization updated</p>
                      <p className="text-xs text-gray-500">Team structure modified - 1 day ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <UserManagement users={allUsers || []} />
          </TabsContent>

          <TabsContent value="organization" className="space-y-6">
            <OrgChart users={allUsers || []} />
          </TabsContent>

          <TabsContent value="system" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Database Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Connection Status</span>
                      <Badge className="bg-green-100 text-green-800">Connected</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Last Backup</span>
                      <span className="text-sm">2 hours ago</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Storage Used</span>
                      <span className="text-sm">245 MB</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>API Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">OpenAI API</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Email Service</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">Authentication</span>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>System Logs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  <div className="text-xs font-mono bg-gray-50 p-3 rounded">
                    <span className="text-gray-500">[2024-01-22 10:30:15]</span>
                    <span className="text-green-600 ml-2">INFO</span>
                    <span className="ml-2">User authentication successful: sarah.chen@holidaytribe.com</span>
                  </div>
                  <div className="text-xs font-mono bg-gray-50 p-3 rounded">
                    <span className="text-gray-500">[2024-01-22 10:25:42]</span>
                    <span className="text-blue-600 ml-2">DEBUG</span>
                    <span className="ml-2">AI prompt processed successfully</span>
                  </div>
                  <div className="text-xs font-mono bg-gray-50 p-3 rounded">
                    <span className="text-gray-500">[2024-01-22 10:20:18]</span>
                    <span className="text-green-600 ml-2">INFO</span>
                    <span className="ml-2">Database backup completed</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>
    </>
  );
}
