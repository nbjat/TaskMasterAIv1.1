import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getAuthHeaders } from "@/lib/auth";
import { useAuth } from "@/hooks/use-auth";
import Header from "@/components/layout/header";
import PromptInterface from "@/components/ai/prompt-interface";
import StatsCards from "@/components/dashboard/stats-cards";
import TaskCard from "@/components/tasks/task-card";
import TaskModal from "@/components/tasks/task-modal";
import TeamActivity from "@/components/dashboard/team-activity";
import QuickActions from "@/components/dashboard/quick-actions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Filter, Lightbulb } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const [taskModalOpen, setTaskModalOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<number | undefined>();
  const [taskFilter, setTaskFilter] = useState("all");

  // Fetch dashboard stats
  const { data: stats } = useQuery({
    queryKey: ['/api/analytics/stats'],
    queryFn: async () => {
      const response = await fetch('/api/analytics/stats', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
  });

  // Fetch recent tasks
  const { data: tasks } = useQuery({
    queryKey: ['/api/tasks', taskFilter],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (taskFilter !== 'all') {
        params.append('status', taskFilter);
      }
      const response = await fetch(`/api/tasks?${params}`, {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
  });

  // Mock team activity data - in real app this would come from API
  const teamActivity = [
    {
      id: 1,
      user: { id: 2, name: "Nitin Sharma" },
      action: "completed SEO Research",
      createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 2,
      user: { id: 3, name: "Rituja Patel" },
      action: "started Design Review",
      createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    },
    {
      id: 3,
      user: { id: 4, name: "Devansh Kumar" },
      action: "created new task",
      createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    },
  ];

  const handleTaskClick = (taskId: number) => {
    setSelectedTask(taskId);
    setTaskModalOpen(true);
  };

  const handleNewTask = () => {
    setSelectedTask(undefined);
    setTaskModalOpen(true);
  };

  const handlePromptResult = (result: any) => {
    if (result.action === 'create_task' && result.parameters) {
      // Auto-open task creation modal with pre-filled data
      setSelectedTask(undefined);
      setTaskModalOpen(true);
    }
    // Handle other AI actions here
  };

  return (
    <>
      <Header 
        title="Dashboard" 
        description="Manage your tasks with AI-powered assistance"
        onNewTask={handleNewTask}
      />
      
      <PromptInterface onPromptResult={handlePromptResult} />

      <main className="flex-1 p-6 overflow-auto">
        {stats && <StatsCards stats={stats} />}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Task List */}
          <div className="lg:col-span-2">
            <Card className="border border-gray-200">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg">Recent Tasks</CardTitle>
                  <div className="flex items-center space-x-2">
                    <Select value={taskFilter} onValueChange={setTaskFilter}>
                      <SelectTrigger className="w-[180px]">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Tasks</SelectItem>
                        <SelectItem value="todo">To Do</SelectItem>
                        <SelectItem value="in_progress">In Progress</SelectItem>
                        <SelectItem value="in_review">In Review</SelectItem>
                        <SelectItem value="blocked">Blocked</SelectItem>
                        <SelectItem value="done">Completed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Filter className="w-4 h-4 text-gray-600" />
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="p-0">
                {tasks && tasks.length > 0 ? (
                  <div className="divide-y divide-gray-200">
                    {tasks.slice(0, 10).map((task: any) => (
                      <div key={task.id} className="p-6 hover:bg-gray-50 transition-colors">
                        <TaskCard 
                          task={task} 
                          onClick={() => handleTaskClick(task.id)}
                          compact
                        />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-6 text-center text-gray-500">
                    No tasks found. Create your first task using the AI assistant above!
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            <QuickActions 
              onGenerateReport={() => {
                // Handle report generation
              }}
              onCheckWorkload={() => {
                // Handle workload check
              }}
              onSendReminders={() => {
                // Handle reminders
              }}
            />

            <TeamActivity activities={teamActivity} />

            {/* AI Insights */}
            <Card className="border border-primary/20 ai-gradient text-white">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Lightbulb className="w-5 h-5 mr-2" />
                  AI Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="bg-white/20 rounded-lg p-3">
                    <p className="text-sm font-medium">Workload Alert</p>
                    <p className="text-xs text-white/90">
                      You have 3 high-priority tasks due this week
                    </p>
                  </div>
                  <div className="bg-white/20 rounded-lg p-3">
                    <p className="text-sm font-medium">Productivity Tip</p>
                    <p className="text-xs text-white/90">
                      Team completes 15% more tasks on Tuesdays
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>

      <TaskModal
        isOpen={taskModalOpen}
        onClose={() => setTaskModalOpen(false)}
        taskId={selectedTask}
        mode={selectedTask ? 'edit' : 'create'}
      />
    </>
  );
}
