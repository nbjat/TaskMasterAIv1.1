import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Table, Upload, Download, Edit, Users } from "lucide-react";

interface OrgChartProps {
  users: Array<{
    id: number;
    name: string;
    email: string;
    role: string;
    managerId?: number;
  }>;
}

export default function OrgChart({ users }: OrgChartProps) {
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [newManagerId, setNewManagerId] = useState<string>('');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const updateUserMutation = useMutation({
    mutationFn: async ({ userId, updates }: { userId: number; updates: any }) => {
      const response = await apiRequest('PATCH', `/api/users/${userId}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      toast({
        title: "User Updated",
        description: "User information has been updated successfully",
      });
      setEditModalOpen(false);
      setSelectedUser(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update user",
        variant: "destructive",
      });
    },
  });

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const buildOrgTree = () => {
    const userMap = new Map(users.map(user => [user.id, user]));
    const rootUsers: any[] = [];
    const childrenMap = new Map<number, any[]>();

    users.forEach(user => {
      if (!user.managerId) {
        rootUsers.push(user);
      } else {
        if (!childrenMap.has(user.managerId)) {
          childrenMap.set(user.managerId, []);
        }
        childrenMap.get(user.managerId)!.push(user);
      }
    });

    const buildTree = (user: any): any => ({
      ...user,
      children: childrenMap.get(user.id) || [],
    });

    return rootUsers.map(buildTree);
  };

  const handleEditUser = (user: any) => {
    setSelectedUser(user);
    setNewManagerId(user.managerId?.toString() || '');
    setEditModalOpen(true);
  };

  const handleUpdateUser = () => {
    if (!selectedUser) return;

    const updates: any = {};
    if (newManagerId !== (selectedUser.managerId?.toString() || '')) {
      updates.managerId = newManagerId ? parseInt(newManagerId) : null;
    }

    if (Object.keys(updates).length > 0) {
      updateUserMutation.mutate({ userId: selectedUser.id, updates });
    } else {
      setEditModalOpen(false);
    }
  };

  const renderUserNode = (user: any, level = 0) => {
    const hasChildren = user.children && user.children.length > 0;
    
    return (
      <div key={user.id} className={`${level > 0 ? 'ml-8' : ''}`}>
        <div className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg mb-4 bg-white">
          <Avatar className="w-12 h-12">
            <AvatarFallback className="bg-primary text-white">
              {getInitials(user.name)}
            </AvatarFallback>
          </Avatar>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-3">
              <p className="font-medium text-gray-900">{user.name}</p>
              <Badge 
                variant="outline" 
                className={
                  user.role === 'admin' ? 'border-red-200 text-red-700' :
                  user.role === 'manager' ? 'border-blue-200 text-blue-700' :
                  'border-gray-200 text-gray-700'
                }
              >
                {user.role}
              </Badge>
              {hasChildren && (
                <Badge variant="outline" className="text-xs">
                  <Users className="w-3 h-3 mr-1" />
                  {user.children.length} direct report{user.children.length !== 1 ? 's' : ''}
                </Badge>
              )}
            </div>
            <p className="text-sm text-gray-500">{user.email}</p>
          </div>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => handleEditUser(user)}
          >
            <Edit className="w-4 h-4" />
          </Button>
        </div>
        
        {hasChildren && (
          <div className="border-l-2 border-gray-200 ml-6 pl-2">
            {user.children.map((child: any) => renderUserNode(child, level + 1))}
          </div>
        )}
      </div>
    );
  };

  const orgTree = buildOrgTree();
  const availableManagers = users.filter(user => 
    user.role === 'admin' || user.role === 'manager'
  );

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Table className="w-5 h-5 mr-2" />
              Organization Chart
            </CardTitle>
            <div className="flex space-x-2">
              <Button variant="outline" size="sm">
                <Upload className="w-4 h-4 mr-2" />
                Import CSV
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {orgTree.length > 0 ? (
            <div className="space-y-4">
              {orgTree.map(user => renderUserNode(user))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Table className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-500">No organization structure found.</p>
              <p className="text-sm text-gray-400">Users will be listed here once manager relationships are established.</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Dialog open={editModalOpen} onOpenChange={setEditModalOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit User Reporting Structure</DialogTitle>
          </DialogHeader>
          
          {selectedUser && (
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                <Avatar>
                  <AvatarFallback className="bg-primary text-white">
                    {getInitials(selectedUser.name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{selectedUser.name}</p>
                  <p className="text-sm text-gray-500">{selectedUser.email}</p>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Reports To
                </label>
                <Select value={newManagerId} onValueChange={setNewManagerId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select manager (or leave empty for no manager)" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">No Manager</SelectItem>
                    {availableManagers
                      .filter(manager => manager.id !== selectedUser.id)
                      .map(manager => (
                        <SelectItem key={manager.id} value={manager.id.toString()}>
                          {manager.name} ({manager.role})
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end space-x-2 pt-4">
                <Button variant="outline" onClick={() => setEditModalOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateUser}
                  disabled={updateUserMutation.isPending}
                >
                  Update Structure
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
