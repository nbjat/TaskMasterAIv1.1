import { Card, CardContent } from "@/components/ui/card";
import { CheckSquare, Clock, CheckCircle, AlertTriangle, TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface StatsCardsProps {
  stats: {
    total: number;
    inProgress: number;
    completed: number;
    overdue: number;
  };
}

export default function StatsCards({ stats }: StatsCardsProps) {
  const cards = [
    {
      title: "Total Tasks",
      value: stats.total,
      icon: CheckSquare,
      color: "text-primary",
      bgColor: "bg-primary/10",
      trend: { value: 12, isPositive: true },
    },
    {
      title: "In Progress",
      value: stats.inProgress,
      icon: Clock,
      color: "text-warning",
      bgColor: "bg-warning/10",
      subtitle: "Active work items",
    },
    {
      title: "Completed",
      value: stats.completed,
      icon: CheckCircle,
      color: "text-success",
      bgColor: "bg-success/10",
      trend: { value: 85, label: "completion rate" },
    },
    {
      title: "Overdue",
      value: stats.overdue,
      icon: AlertTriangle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
      subtitle: "Needs attention",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
      {cards.map((card, index) => (
        <Card key={index} className="border border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className="text-3xl font-bold text-gray-900">{card.value}</p>
              </div>
              <div className={cn("p-3 rounded-lg", card.bgColor)}>
                <card.icon className={cn("w-6 h-6", card.color)} />
              </div>
            </div>
            
            <div className="mt-4 flex items-center text-sm">
              {card.trend && (
                <>
                  {card.trend.isPositive ? (
                    <TrendingUp className="w-4 h-4 text-success mr-1" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-destructive mr-1" />
                  )}
                  <span className={card.trend.isPositive ? "text-success" : "text-destructive"}>
                    {card.trend.value}%
                  </span>
                  <span className="text-gray-600 ml-1">
                    {card.trend.label || "from last week"}
                  </span>
                </>
              )}
              {card.subtitle && (
                <span className="text-gray-600">{card.subtitle}</span>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
