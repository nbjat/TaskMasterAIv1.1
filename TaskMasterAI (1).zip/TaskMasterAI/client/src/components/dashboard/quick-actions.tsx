import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { BarChart3, Users, Bell } from "lucide-react";

interface QuickActionsProps {
  onGenerateReport?: () => void;
  onCheckWorkload?: () => void;
  onSendReminders?: () => void;
}

export default function QuickActions({ 
  onGenerateReport, 
  onCheckWorkload, 
  onSendReminders 
}: QuickActionsProps) {
  const actions = [
    {
      title: "Generate Weekly Report",
      icon: BarChart3,
      color: "text-primary",
      onClick: onGenerateReport,
    },
    {
      title: "Check Team Workload",
      icon: Users,
      color: "text-secondary",
      onClick: onCheckWorkload,
    },
    {
      title: "Send Deadline Reminders",
      icon: Bell,
      color: "text-warning",
      onClick: onSendReminders,
    },
  ];

  return (
    <Card className="border border-gray-200">
      <CardHeader>
        <CardTitle className="text-lg">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {actions.map((action, index) => (
            <Button
              key={index}
              variant="outline"
              className="w-full justify-start h-auto p-3"
              onClick={action.onClick}
            >
              <action.icon className={`w-5 h-5 mr-3 ${action.color}`} />
              <span className="font-medium">{action.title}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
