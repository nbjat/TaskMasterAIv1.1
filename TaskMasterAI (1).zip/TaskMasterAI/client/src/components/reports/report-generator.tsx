import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Calendar, Mail, FileText, User, BarChart3 } from "lucide-react";
import { format, subDays, subWeeks } from "date-fns";

interface ReportGeneratorProps {
  onGenerate: (params: {
    type: 'daily' | 'weekly' | 'stakeholder';
    userId?: number;
    emailTo?: string;
  }) => void;
  teamMembers: Array<{
    id: number;
    name: string;
    email: string;
  }>;
  isLoading: boolean;
}

export default function ReportGenerator({ onGenerate, teamMembers, isLoading }: ReportGeneratorProps) {
  const [reportType, setReportType] = useState<'daily' | 'weekly' | 'stakeholder'>('weekly');
  const [selectedUserId, setSelectedUserId] = useState<string>('');
  const [emailTo, setEmailTo] = useState('');
  const [sendEmail, setSendEmail] = useState(false);
  const [dateRange, setDateRange] = useState({
    start: format(subWeeks(new Date(), 1), 'yyyy-MM-dd'),
    end: format(new Date(), 'yyyy-MM-dd'),
  });

  const handleGenerateReport = () => {
    const params: any = {
      type: reportType,
    };

    if (selectedUserId) {
      params.userId = parseInt(selectedUserId);
    }

    if (sendEmail && emailTo) {
      params.emailTo = emailTo;
    }

    onGenerate(params);
  };

  const reportTypes = [
    {
      value: 'daily',
      label: 'Daily Report',
      description: 'Today\'s task summary and progress',
      icon: Calendar,
    },
    {
      value: 'weekly',
      label: 'Weekly Report',
      description: 'Weekly accomplishments and upcoming work',
      icon: BarChart3,
    },
    {
      value: 'stakeholder',
      label: 'Stakeholder Report',
      description: 'High-level overview for management',
      icon: User,
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="w-5 h-5 mr-2" />
          Custom Report Generator
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Report Type Selection */}
        <div>
          <Label className="text-base font-medium mb-3 block">Report Type</Label>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {reportTypes.map((type) => (
              <div
                key={type.value}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  reportType === type.value
                    ? 'border-primary bg-primary/5'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
                onClick={() => setReportType(type.value as any)}
              >
                <div className="flex items-center space-x-3">
                  <type.icon className={`w-5 h-5 ${
                    reportType === type.value ? 'text-primary' : 'text-gray-400'
                  }`} />
                  <div>
                    <p className="font-medium text-gray-900">{type.label}</p>
                    <p className="text-sm text-gray-500">{type.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* User Selection */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label htmlFor="user-select">Report For</Label>
            <Select value={selectedUserId} onValueChange={setSelectedUserId}>
              <SelectTrigger>
                <SelectValue placeholder="Select user" />
              </SelectTrigger>
              <SelectContent>
                {teamMembers.map((member) => (
                  <SelectItem key={member.id} value={member.id.toString()}>
                    {member.name} {member.name === 'Myself' ? '' : `(${member.email})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label htmlFor="date-range">Date Range</Label>
            <Select 
              value={`${dateRange.start}-${dateRange.end}`}
              onValueChange={(value) => {
                const [start, end] = value.split('-');
                setDateRange({ start, end });
              }}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={`${format(subDays(new Date(), 1), 'yyyy-MM-dd')}-${format(new Date(), 'yyyy-MM-dd')}`}>
                  Yesterday
                </SelectItem>
                <SelectItem value={`${format(subDays(new Date(), 7), 'yyyy-MM-dd')}-${format(new Date(), 'yyyy-MM-dd')}`}>
                  Last 7 days
                </SelectItem>
                <SelectItem value={`${format(subWeeks(new Date(), 1), 'yyyy-MM-dd')}-${format(new Date(), 'yyyy-MM-dd')}`}>
                  Last week
                </SelectItem>
                <SelectItem value={`${format(subWeeks(new Date(), 2), 'yyyy-MM-dd')}-${format(new Date(), 'yyyy-MM-dd')}`}>
                  Last 2 weeks
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Email Options */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <Checkbox
              id="send-email"
              checked={sendEmail}
              onCheckedChange={setSendEmail}
            />
            <Label htmlFor="send-email" className="flex items-center">
              <Mail className="w-4 h-4 mr-2" />
              Email report after generation
            </Label>
          </div>

          {sendEmail && (
            <div>
              <Label htmlFor="email-to">Email Address</Label>
              <Input
                id="email-to"
                type="email"
                placeholder="recipient@holidaytribe.com"
                value={emailTo}
                onChange={(e) => setEmailTo(e.target.value)}
              />
            </div>
          )}
        </div>

        {/* Generate Button */}
        <div className="pt-4 border-t">
          <Button
            onClick={handleGenerateReport}
            disabled={isLoading || !selectedUserId || (sendEmail && !emailTo)}
            className="w-full md:w-auto"
          >
            {isLoading ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Generating Report...
              </>
            ) : (
              <>
                <FileText className="w-4 h-4 mr-2" />
                Generate Report
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
