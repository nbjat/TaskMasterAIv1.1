import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Brain, Send, Lightbulb } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { getAuthHeaders } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";

interface PromptInterfaceProps {
  onPromptResult?: (result: any) => void;
}

export default function PromptInterface({ onPromptResult }: PromptInterfaceProps) {
  const [prompt, setPrompt] = useState("");
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: suggestions } = useQuery({
    queryKey: ['/api/ai/suggestions'],
    queryFn: async () => {
      const response = await fetch('/api/ai/suggestions', {
        headers: getAuthHeaders(),
      });
      return response.json();
    },
  });

  const parsePromptMutation = useMutation({
    mutationFn: async (promptText: string) => {
      const response = await apiRequest('POST', '/api/ai/parse-prompt', { prompt: promptText });
      return response.json();
    },
    onSuccess: (result) => {
      if (result.clarificationNeeded) {
        toast({
          title: "Clarification Needed",
          description: result.clarificationNeeded,
          variant: "destructive",
        });
      } else {
        toast({
          title: "Command Understood",
          description: `Action: ${result.action.replace('_', ' ')}`,
        });
        onPromptResult?.(result);
      }
      setPrompt("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to process your command. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;
    parsePromptMutation.mutate(prompt);
  };

  const handleSuggestionClick = (suggestion: string) => {
    setPrompt(suggestion);
  };

  return (
    <div className="bg-white border-b border-gray-200 px-6 py-4">
      <div className="max-w-4xl">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          <Brain className="inline w-4 h-4 text-primary mr-2" />
          AI Assistant - Type your command
        </label>
        
        <form onSubmit={handleSubmit} className="relative">
          <Input
            type="text"
            placeholder="Try: 'Assign a high-priority task to John to submit report by Friday' or 'Show me overdue tasks'"
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="w-full pr-12"
            disabled={parsePromptMutation.isPending}
          />
          <Button
            type="submit"
            size="sm"
            className="absolute right-3 top-1/2 transform -translate-y-1/2 p-1"
            disabled={!prompt.trim() || parsePromptMutation.isPending}
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>

        {suggestions?.suggestions && (
          <div className="mt-3 flex items-center space-x-4 text-sm text-gray-600">
            <span className="flex items-center">
              <Lightbulb className="w-4 h-4 text-warning mr-1" />
              AI Suggestions:
            </span>
            <div className="flex flex-wrap gap-2">
              {suggestions.suggestions.slice(0, 3).map((suggestion: string, index: number) => (
                <Button
                  key={index}
                  variant="outline"
                  size="sm"
                  className="text-xs"
                  onClick={() => handleSuggestionClick(suggestion)}
                >
                  {suggestion}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
