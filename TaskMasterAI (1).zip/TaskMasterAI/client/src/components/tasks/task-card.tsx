import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Calendar, Tag, User } from "lucide-react";
import { format, isAfter } from "date-fns";
import { cn } from "@/lib/utils";

interface TaskCardProps {
  task: {
    id: number;
    title: string;
    description?: string;
    status: string;
    priority: string;
    dueDate?: string;
    tags?: string[];
    progress: number;
    assignee: {
      id: number;
      name: string;
    };
    creator: {
      id: number;
      name: string;
    };
  };
  onClick?: () => void;
  compact?: boolean;
}

export default function TaskCard({ task, onClick, compact = false }: TaskCardProps) {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'critical':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'high':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low':
        return 'bg-green-100 text-green-800 border-green-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'done':
        return 'bg-green-100 text-green-800';
      case 'in_progress':
        return 'bg-blue-100 text-blue-800';
      case 'in_review':
        return 'bg-purple-100 text-purple-800';
      case 'blocked':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getProgressColor = (progress: number, status: string) => {
    if (status === 'done') return 'bg-green-500';
    if (status === 'blocked') return 'bg-red-500';
    if (progress > 75) return 'bg-green-500';
    if (progress > 50) return 'bg-blue-500';
    if (progress > 25) return 'bg-yellow-500';
    return 'bg-gray-400';
  };

  const isOverdue = task.dueDate && isAfter(new Date(), new Date(task.dueDate)) && task.status !== 'done';

  return (
    <Card 
      className={cn(
        "border border-gray-200 hover:bg-gray-50 transition-colors cursor-pointer",
        `task-priority-${task.priority}`,
        isOverdue && "border-red-300 bg-red-50"
      )}
      onClick={onClick}
    >
      <CardContent className={cn("p-6", compact && "p-4")}>
        <div className="flex items-start justify-between">
          <div className="flex-1 min-w-0">
            <div className="flex items-center space-x-3 mb-2">
              <h4 className={cn(
                "font-medium text-gray-900 truncate",
                compact ? "text-sm" : "text-base"
              )}>
                {task.title}
              </h4>
              <Badge className={cn("text-xs", getPriorityColor(task.priority))}>
                {task.priority}
              </Badge>
              <Badge className={cn("text-xs", getStatusColor(task.status))}>
                {task.status.replace('_', ' ')}
              </Badge>
            </div>
            
            {task.description && !compact && (
              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                {task.description}
              </p>
            )}
            
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span className="flex items-center">
                <User className="w-4 h-4 mr-1" />
                {task.assignee.name}
              </span>
              
              {task.dueDate && (
                <span className={cn(
                  "flex items-center",
                  isOverdue && "text-red-600 font-medium"
                )}>
                  <Calendar className="w-4 h-4 mr-1" />
                  Due: {format(new Date(task.dueDate), 'MMM d, yyyy')}
                </span>
              )}
              
              {task.tags && task.tags.length > 0 && (
                <span className="flex items-center">
                  <Tag className="w-4 h-4 mr-1" />
                  {task.tags.slice(0, 2).join(', ')}
                  {task.tags.length > 2 && ` +${task.tags.length - 2}`}
                </span>
              )}
            </div>
          </div>
          
          <div className="flex items-center space-x-3 ml-4">
            <div className="flex items-center space-x-2">
              <div className="w-16 bg-gray-200 rounded-full h-2">
                <div 
                  className={cn("h-2 rounded-full", getProgressColor(task.progress, task.status))}
                  style={{ width: `${task.progress}%` }}
                />
              </div>
              <span className="text-xs text-gray-600 min-w-[3ch]">
                {task.progress}%
              </span>
            </div>
            
            <Avatar className="w-8 h-8">
              <AvatarFallback className="bg-primary text-white text-xs">
                {getInitials(task.assignee.name)}
              </AvatarFallback>
            </Avatar>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
