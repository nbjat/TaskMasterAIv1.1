import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { BarChart3, AlertTriangle, CheckCircle, Clock } from "lucide-react";

interface WorkloadChartProps {
  teamMembers: Array<{
    id: number;
    name: string;
    email: string;
  }>;
  tasks: Array<{
    id: number;
    assigneeId: number;
    status: string;
    priority: string;
    dueDate?: string;
  }>;
}

export default function WorkloadChart({ teamMembers, tasks }: WorkloadChartProps) {
  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase();
  };

  const getWorkloadData = (memberId: number) => {
    const memberTasks = tasks.filter(task => task.assigneeId === memberId);
    const total = memberTasks.length;
    const inProgress = memberTasks.filter(task => task.status === 'in_progress').length;
    const completed = memberTasks.filter(task => task.status === 'done').length;
    const overdue = memberTasks.filter(task => {
      if (!task.dueDate || task.status === 'done') return false;
      return new Date(task.dueDate) < new Date();
    }).length;
    const highPriority = memberTasks.filter(task => 
      task.priority === 'high' || task.priority === 'critical'
    ).length;

    return { total, inProgress, completed, overdue, highPriority };
  };

  const getWorkloadLevel = (total: number) => {
    if (total >= 8) return { level: 'High', color: 'bg-red-500', textColor: 'text-red-600' };
    if (total >= 5) return { level: 'Medium', color: 'bg-yellow-500', textColor: 'text-yellow-600' };
    return { level: 'Low', color: 'bg-green-500', textColor: 'text-green-600' };
  };

  const maxTasks = Math.max(...teamMembers.map(member => getWorkloadData(member.id).total), 1);

  return (
    <div className="space-y-6">
      {/* Workload Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart3 className="w-5 h-5 mr-2" />
            Team Workload Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {teamMembers.map(member => {
              const workload = getWorkloadData(member.id);
              const level = getWorkloadLevel(workload.total);
              const completionRate = workload.total > 0 ? Math.round((workload.completed / workload.total) * 100) : 0;

              return (
                <div key={member.id} className="flex items-center space-x-4 p-4 border border-gray-200 rounded-lg">
                  <Avatar className="w-12 h-12">
                    <AvatarFallback className="bg-primary text-white">
                      {getInitials(member.name)}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-2">
                      <div>
                        <p className="font-medium text-gray-900">{member.name}</p>
                        <p className="text-sm text-gray-500">{workload.total} tasks assigned</p>
                      </div>
                      <Badge className={`${level.textColor} bg-transparent border-current`}>
                        {level.level} Load
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span>Task Progress</span>
                        <span>{completionRate}% Complete</span>
                      </div>
                      <Progress value={completionRate} className="h-2" />
                      
                      <div className="flex items-center justify-between text-sm">
                        <span>Workload vs Team Max</span>
                        <span>{Math.round((workload.total / maxTasks) * 100)}%</span>
                      </div>
                      <Progress value={(workload.total / maxTasks) * 100} className="h-2" />
                    </div>

                    <div className="flex items-center space-x-4 mt-3 text-sm">
                      <div className="flex items-center space-x-1">
                        <Clock className="w-4 h-4 text-blue-600" />
                        <span>{workload.inProgress} in progress</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <CheckCircle className="w-4 h-4 text-green-600" />
                        <span>{workload.completed} completed</span>
                      </div>
                      {workload.overdue > 0 && (
                        <div className="flex items-center space-x-1">
                          <AlertTriangle className="w-4 h-4 text-red-600" />
                          <span className="text-red-600">{workload.overdue} overdue</span>
                        </div>
                      )}
                      {workload.highPriority > 0 && (
                        <Badge variant="outline" className="text-xs">
                          {workload.highPriority} high priority
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Workload Distribution Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Workload Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {teamMembers.map(member => {
              const workload = getWorkloadData(member.id);
              const percentage = maxTasks > 0 ? (workload.total / maxTasks) * 100 : 0;
              
              return (
                <div key={member.id} className="flex items-center space-x-4">
                  <div className="w-24 text-sm font-medium text-gray-700 truncate">
                    {member.name.split(' ')[0]}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-8 relative">
                        <div
                          className="bg-primary h-8 rounded-full flex items-center justify-center text-white text-sm font-medium"
                          style={{ width: `${Math.max(percentage, 5)}%` }}
                        >
                          {workload.total > 0 && workload.total}
                        </div>
                      </div>
                      <span className="text-sm text-gray-600 w-12 text-right">
                        {workload.total}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
