export function getAuthHeaders(): Record<string, string> {
  const token = localStorage.getItem('taskmaster_token');
  return token ? { 'Authorization': `Bearer ${token}` } : {};
}

export function isAuthenticated(): boolean {
  return !!localStorage.getItem('taskmaster_token');
}

export function hasRole(userRole: string, requiredRoles: string[]): boolean {
  return requiredRoles.includes(userRole);
}

export function canManageTask(userRole: string, userId: number, task: { creatorId: number; assigneeId: number }): boolean {
  if (userRole === 'admin') return true;
  if (userRole === 'manager') return true;
  if (userRole === 'ic') return task.assigneeId === userId || task.creatorId === userId;
  return false;
}
