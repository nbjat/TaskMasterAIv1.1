import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

interface ParsedPrompt {
  action: 'create_task' | 'update_task' | 'generate_report' | 'query_tasks' | 'check_workload' | 'unknown';
  confidence: number;
  parameters: {
    title?: string;
    description?: string;
    assignee?: string;
    assigneeId?: number;
    priority?: 'low' | 'medium' | 'high' | 'critical';
    dueDate?: string;
    status?: 'todo' | 'in_progress' | 'blocked' | 'in_review' | 'done';
    tags?: string[];
    taskId?: number;
    reportType?: 'daily' | 'weekly' | 'stakeholder';
    userId?: number;
    teamId?: number;
    filters?: Record<string, any>;
  };
  clarificationNeeded?: string;
}

export async function parsePrompt(prompt: string, userContext?: { 
  userId: number; 
  role: string; 
  managerId?: number;
  teamMembers?: Array<{ id: number; name: string; email: string }>;
}): Promise<ParsedPrompt> {
  try {
    const systemPrompt = `You are an AI assistant for TaskMaster, a task management system for HolidayTribe employees. 
    Parse user prompts and extract structured task management actions.
    
    Available actions:
    - create_task: Creating new tasks
    - update_task: Updating existing tasks (status, priority, assignee, etc.)
    - generate_report: Creating daily/weekly/stakeholder reports
    - query_tasks: Searching or filtering tasks
    - check_workload: Checking team member workload
    - unknown: When intent is unclear
    
    Available team members: ${userContext?.teamMembers?.map(m => `${m.name} (${m.email})`).join(', ') || 'None'}
    User role: ${userContext?.role || 'unknown'}
    
    Priority levels: low, medium, high, critical
    Status options: todo, in_progress, blocked, in_review, done
    
    Return JSON with: action, confidence (0-1), parameters, and clarificationNeeded if confidence < 0.8
    
    Examples:
    - "Assign a high-priority task to Rituja to submit hiring data by Friday" → create_task
    - "Update the SEO task status to in progress" → update_task  
    - "Show me overdue tasks" → query_tasks
    - "Generate weekly report for my team" → generate_report`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: prompt }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    
    // Map assignee names to IDs if team members provided
    if (result.parameters?.assignee && userContext?.teamMembers) {
      const member = userContext.teamMembers.find(m => 
        m.name.toLowerCase().includes(result.parameters.assignee.toLowerCase()) ||
        m.email.toLowerCase().includes(result.parameters.assignee.toLowerCase())
      );
      if (member) {
        result.parameters.assigneeId = member.id;
      }
    }

    return {
      action: result.action || 'unknown',
      confidence: Math.max(0, Math.min(1, result.confidence || 0)),
      parameters: result.parameters || {},
      clarificationNeeded: result.confidence < 0.8 ? result.clarificationNeeded : undefined,
    };
  } catch (error) {
    console.error('AI parsing error:', error);
    return {
      action: 'unknown',
      confidence: 0,
      parameters: {},
      clarificationNeeded: 'I could not understand your request. Please try rephrasing or use more specific language.',
    };
  }
}

export async function generateReport(
  type: 'daily' | 'weekly' | 'stakeholder',
  data: {
    tasks: Array<any>;
    user?: any;
    team?: Array<any>;
    dateRange?: { start: Date; end: Date };
  }
): Promise<string> {
  try {
    const systemPrompt = `You are an AI assistant generating ${type} reports for TaskMaster.
    Create professional, concise reports based on task data.
    
    For daily reports: Focus on completed tasks, current progress, and next day priorities
    For weekly reports: Summarize week's accomplishments, blockers, and upcoming work
    For stakeholder reports: High-level overview of progress, risks, and key metrics
    
    Format as markdown with clear sections and bullet points.`;

    const dataContext = `
    Report Type: ${type}
    Tasks Data: ${JSON.stringify(data.tasks, null, 2)}
    User: ${data.user ? JSON.stringify(data.user) : 'N/A'}
    Team: ${data.team ? JSON.stringify(data.team) : 'N/A'}
    Date Range: ${data.dateRange ? `${data.dateRange.start.toDateString()} to ${data.dateRange.end.toDateString()}` : 'N/A'}
    `;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: `Generate a ${type} report based on this data:\n\n${dataContext}` }
      ],
    });

    return response.choices[0].message.content || 'Unable to generate report';
  } catch (error) {
    console.error('Report generation error:', error);
    return 'Error generating report. Please try again.';
  }
}

export async function generateTaskSuggestions(context: {
  recentTasks: Array<any>;
  userRole: string;
  teamWorkload?: Array<any>;
}): Promise<string[]> {
  try {
    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "Generate 3-5 helpful task management suggestions based on user context. Return as JSON array of strings."
        },
        {
          role: "user",
          content: `Context: ${JSON.stringify(context)}`
        }
      ],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || '{"suggestions": []}');
    return result.suggestions || [];
  } catch (error) {
    console.error('Suggestion generation error:', error);
    return [
      "Create a new task",
      "Update task status",
      "Generate weekly report",
      "Check team workload"
    ];
  }
}
