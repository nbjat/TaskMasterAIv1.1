import nodemailer from 'nodemailer';

// Email service configured successfully

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || 'smtp.gmail.com',
  port: parseInt(process.env.SMTP_PORT || '587'),
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASSWORD,
  },
});

export async function sendOTPEmail(email: string, otp: string): Promise<void> {
  const mailOptions = {
    from: process.env.SMTP_FROM || 'noreply@holidaytribe.com',
    to: email,
    subject: 'TaskMaster AI - Login Verification Code',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #6366F1 0%, #10B981 100%); padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">TaskMaster AI</h1>
          <p style="color: white; margin: 5px 0;">HolidayTribe Task Management</p>
        </div>
        
        <div style="padding: 40px 20px; background: #f9f9f9;">
          <h2 style="color: #333; margin-bottom: 20px;">Your Login Verification Code</h2>
          
          <div style="background: white; padding: 30px; border-radius: 8px; text-align: center; margin: 20px 0;">
            <p style="color: #666; margin-bottom: 20px;">Enter this code to access your TaskMaster AI account:</p>
            <div style="font-size: 32px; font-weight: bold; color: #6366F1; letter-spacing: 8px; margin: 20px 0;">
              ${otp}
            </div>
            <p style="color: #999; font-size: 14px; margin-top: 20px;">This code will expire in 10 minutes</p>
          </div>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px;">
            If you didn't request this code, please ignore this email or contact your administrator.
          </p>
        </div>
        
        <div style="background: #333; color: white; padding: 20px; text-align: center; font-size: 12px;">
          <p style="margin: 0;">© 2024 HolidayTribe. All rights reserved.</p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Failed to send OTP email:', error);
    throw new Error('Failed to send verification email');
  }
}

export async function sendReportEmail(
  email: string,
  subject: string,
  reportContent: string,
  reportType: 'daily' | 'weekly' | 'stakeholder'
): Promise<void> {
  const mailOptions = {
    from: process.env.SMTP_FROM || 'reports@holidaytribe.com',
    to: email,
    subject: `TaskMaster AI - ${subject}`,
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto;">
        <div style="background: linear-gradient(135deg, #6366F1 0%, #10B981 100%); padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0;">TaskMaster AI</h1>
          <p style="color: white; margin: 5px 0;">${subject}</p>
        </div>
        
        <div style="padding: 40px 20px; background: #f9f9f9;">
          <div style="background: white; padding: 30px; border-radius: 8px;">
            <div style="white-space: pre-wrap; line-height: 1.6; color: #333;">
              ${reportContent.replace(/\n/g, '<br>')}
            </div>
          </div>
          
          <p style="color: #666; font-size: 14px; margin-top: 30px; text-align: center;">
            Generated automatically by TaskMaster AI on ${new Date().toLocaleDateString()}
          </p>
        </div>
        
        <div style="background: #333; color: white; padding: 20px; text-align: center; font-size: 12px;">
          <p style="margin: 0;">© 2024 HolidayTribe. All rights reserved.</p>
        </div>
      </div>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
  } catch (error) {
    console.error('Failed to send report email:', error);
    throw new Error('Failed to send report email');
  }
}
