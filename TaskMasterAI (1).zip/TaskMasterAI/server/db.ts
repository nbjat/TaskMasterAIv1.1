import mongoose from 'mongoose';

const MONGODB_URI = 'mongodb+srv://nbjatsikar:fFTW4Ru6o5SXSR0T@rankit.txutpvf.mongodb.net/TaskMasterAI';

if (!MONGODB_URI) {
  throw new Error('MongoDB URI is required');
}

export async function connectToDatabase() {
  try {
    // Check if already connected
    if (mongoose.connection.readyState === 1) {
      console.log('Already connected to MongoDB');
      return;
    }

    console.log('Connecting to MongoDB Atlas...');
    console.log('URI:', MONGODB_URI.replace(/\/\/.*:.*@/, '//***:***@'));
    
    // Use minimal connection options to avoid configuration issues
    await mongoose.connect(MONGODB_URI);
    
    console.log('✓ Connected to MongoDB Atlas successfully');
    console.log('✓ Database name: TaskMasterAI');
    
    // Connection event handlers
    mongoose.connection.on('error', (error) => {
      console.error('MongoDB connection error:', error);
    });
    
    mongoose.connection.on('disconnected', () => {
      console.log('MongoDB disconnected');
    });
    
    mongoose.connection.on('reconnected', () => {
      console.log('MongoDB reconnected');
    });
    
  } catch (error) {
    console.error('MongoDB connection failed:', error instanceof Error ? error.message : 'Unknown error');
    throw error instanceof Error ? error : new Error('Unknown connection error');
  }
}

// Initialize connection immediately
connectToDatabase().catch(console.error);