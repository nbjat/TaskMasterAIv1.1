import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { authenticateToken, requireRole, generateToken, isValidHolidayTribeEmail, generateOTP, type AuthRequest } from "./services/auth";
import { parsePrompt, generateReport, generateTaskSuggestions } from "./services/ai";
import { sendOTPEmail, sendReportEmail } from "./services/email";
import { insertUserSchema, insertTaskSchema, insertCommentSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth routes
  app.post("/api/auth/request-otp", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email || !isValidHolidayTribeEmail(email)) {
        return res.status(400).json({ 
          message: "Please use your @holidaytribe.com email address" 
        });
      }

      const otp = generateOTP();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      await storage.createOtpToken({
        email,
        code: otp,
        expiresAt: expiresAt.toISOString(),
      });

      await sendOTPEmail(email, otp);

      res.json({ message: "Verification code sent to your email" });
    } catch (error) {
      console.error("OTP request error:", error);
      res.status(500).json({ message: "Failed to send verification code" });
    }
  });

  app.post("/api/auth/verify-otp", async (req, res) => {
    try {
      const { email, otp } = req.body;

      if (!email || !otp) {
        return res.status(400).json({ message: "Email and OTP are required" });
      }

      const otpToken = await storage.getValidOtpToken(email, otp);
      if (!otpToken) {
        return res.status(400).json({ message: "Invalid or expired verification code" });
      }

      await storage.markOtpTokenUsed((otpToken as any)._id.toString());

      let user = await storage.getUserByEmail(email);
      if (!user) {
        // Create new user for valid domain email
        const name = email.split('@')[0].replace(/[._]/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase());
        const [firstName, ...lastNameParts] = name.split(' ');
        user = await storage.createUser({
          username: email.split('@')[0],
          email,
          firstName: firstName || 'User',
          lastName: lastNameParts.join(' ') || 'Name',
          role: "ic", // Default role
          isActive: true,
        });
      }

      // Update last login
      await storage.updateUser((user as any)._id.toString(), { });

      const token = generateToken((user as any)._id.toString(), user.email, user.role);

      res.json({
        token,
        user: {
          id: (user as any)._id.toString(),
          firstName: user.firstName,
          lastName: user.lastName,
          email: user.email,
          role: user.role,
          managerId: user.managerId?.toString(),
        },
      });
    } catch (error) {
      console.error("OTP verification error:", error);
      res.status(500).json({ message: "Authentication failed" });
    }
  });

  app.get("/api/auth/me", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({
        id: (user as any)._id.toString(),
        firstName: user.firstName,
        lastName: user.lastName,
        email: user.email,
        role: user.role,
        managerId: user.managerId?.toString(),
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get user info" });
    }
  });

  // AI prompt route
  app.post("/api/ai/parse-prompt", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { prompt } = req.body;
      
      if (!prompt) {
        return res.status(400).json({ message: "Prompt is required" });
      }

      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get team members if user is a manager
      let teamMembers: any[] = [];
      if (user.role === 'manager' || user.role === 'admin') {
        teamMembers = await storage.getUsersByManager((user as any)._id.toString());
      }

      const userContext = {
        userId: (user as any)._id.toString(),
        role: user.role as "admin" | "manager" | "ic",
        managerId: user.managerId?.toString(),
        teamMembers: teamMembers.map(m => ({ id: (m as any)._id.toString(), name: `${m.firstName} ${m.lastName}`, email: m.email })),
      };

      const parsed = await parsePrompt(prompt, userContext as any);
      res.json(parsed);
    } catch (error) {
      console.error("AI parsing error:", error);
      res.status(500).json({ message: "Failed to parse prompt" });
    }
  });

  // Task routes
  app.get("/api/tasks", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const { status, priority, assigneeId, creatorId, managerId } = req.query;

      let filters: any = {};

      // Role-based filtering
      if (user.role === 'ic') {
        filters.assigneeId = (user as any)._id.toString();
      } else if (user.role === 'manager') {
        if (managerId) {
          filters.managerId = managerId as string;
        } else {
          filters.managerId = (user as any)._id.toString();
        }
      }
      // Admins can see all tasks

      if (status) filters.status = status as string;
      if (priority) filters.priority = priority as string;
      if (assigneeId) filters.assigneeId = assigneeId as string;
      if (creatorId) filters.creatorId = creatorId as string;

      const tasks = await storage.getTasks(filters);
      res.json(tasks);
    } catch (error) {
      console.error("Get tasks error:", error);
      res.status(500).json({ message: "Failed to get tasks" });
    }
  });

  app.get("/api/tasks/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const taskId = req.params.id;
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }

      // Check permissions
      const user = await storage.getUser(req.user!.id);
      if (user?.role === 'ic' && task.assigneeId.toString() !== (user as any)._id.toString()) {
        return res.status(403).json({ message: "Access denied" });
      }

      res.json(task);
    } catch (error) {
      res.status(500).json({ message: "Failed to get task" });
    }
  });

  app.post("/api/tasks", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const taskData = insertTaskSchema.parse({
        ...req.body,
        createdById: req.user!.id,
      });

      const task = await storage.createTask(taskData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid task data", errors: error.errors });
      }
      console.error("Create task error:", error);
      res.status(500).json({ message: "Failed to create task" });
    }
  });

  app.patch("/api/tasks/:id", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const taskId = req.params.id;
      const updates = req.body;

      // Check if task exists and user has permission
      const existingTask = await storage.getTask(taskId);
      if (!existingTask) {
        return res.status(404).json({ message: "Task not found" });
      }

      const user = await storage.getUser(req.user!.id);
      if (user?.role === 'ic' && existingTask.assigneeId.toString() !== (user as any)._id.toString() && existingTask.createdById.toString() !== (user as any)._id.toString()) {
        return res.status(403).json({ message: "Access denied" });
      }

      const task = await storage.updateTask(taskId, updates);
      res.json(task);
    } catch (error) {
      console.error("Update task error:", error);
      res.status(500).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", authenticateToken, requireRole(['admin', 'manager']), async (req: AuthRequest, res) => {
    try {
      const taskId = req.params.id;
      const deleted = await storage.deleteTask(taskId);
      
      if (!deleted) {
        return res.status(404).json({ message: "Task not found" });
      }

      res.json({ message: "Task deleted successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete task" });
    }
  });

  // Task comments
  app.get("/api/tasks/:id/comments", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const taskId = req.params.id;
      const comments = await storage.getTaskComments(taskId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ message: "Failed to get comments" });
    }
  });

  app.post("/api/tasks/:id/comments", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const taskId = req.params.id;
      const { content } = req.body;

      const commentData = insertCommentSchema.parse({
        taskId,
        userId: req.user!.id,
        content,
      });

      const comment = await storage.createComment(commentData);
      res.status(201).json(comment);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid comment data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create comment" });
    }
  });

  // Analytics
  app.get("/api/analytics/stats", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      let stats;
      if (user.role === 'ic') {
        stats = await storage.getTaskStats((user as any)._id.toString());
      } else if (user.role === 'manager') {
        stats = await storage.getTaskStats(undefined, (user as any)._id.toString());
      } else {
        stats = await storage.getTaskStats();
      }

      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to get stats" });
    }
  });

  // Reports
  app.post("/api/reports/generate", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const { type, userId, teamId, startDate, endDate, emailTo } = req.body;

      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Get data for report
      let tasks: any[] = [];
      let reportUser = user;
      let team: any[] = [];

      if (type === 'daily' || type === 'weekly') {
        const dateRange = {
          start: startDate ? new Date(startDate) : new Date(Date.now() - (type === 'weekly' ? 7 : 1) * 24 * 60 * 60 * 1000),
          end: endDate ? new Date(endDate) : new Date(),
        };

        if (userId && userId !== (user as any)._id.toString()) {
          reportUser = await storage.getUser(userId) || user;
        }

        tasks = await storage.getTasks({
          assigneeId: (reportUser as any)._id.toString(),
          dueAfter: dateRange.start,
          dueBefore: dateRange.end,
        });

        if (user.role === 'manager' || user.role === 'admin') {
          team = await storage.getUsersByManager((user as any)._id.toString());
        }
      }

      const reportContent = await generateReport(type, {
        tasks,
        user: reportUser,
        team,
        dateRange: { start: new Date(startDate || Date.now() - 7 * 24 * 60 * 60 * 1000), end: new Date(endDate || Date.now()) },
      });

      // Save report
      await storage.createReport({
        title: `${type.charAt(0).toUpperCase() + type.slice(1)} Report`,
        content: reportContent,
        type,
        recipientEmail: emailTo || user.email,
        generatedById: (user as any)._id.toString(),
      });

      // Send email if requested
      if (emailTo) {
        const subject = `${type.charAt(0).toUpperCase() + type.slice(1)} Report - ${new Date().toLocaleDateString()}`;
        await sendReportEmail(emailTo, subject, reportContent, type);
      }

      res.json({ content: reportContent });
    } catch (error) {
      console.error("Report generation error:", error);
      res.status(500).json({ message: "Failed to generate report" });
    }
  });

  // Users and org management
  app.get("/api/users", authenticateToken, requireRole(['admin', 'manager']), async (req: AuthRequest, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      res.status(500).json({ message: "Failed to get users" });
    }
  });

  app.patch("/api/users/:id", authenticateToken, requireRole(['admin']), async (req: AuthRequest, res) => {
    try {
      const userId = req.params.id;
      const updates = req.body;

      const user = await storage.updateUser(userId, updates);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to update user" });
    }
  });

  app.get("/api/users/team", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user || (user.role !== 'manager' && user.role !== 'admin')) {
        return res.status(403).json({ message: "Access denied" });
      }

      const team = await storage.getUsersByManager((user as any)._id.toString());
      res.json(team);
    } catch (error) {
      res.status(500).json({ message: "Failed to get team" });
    }
  });

  // AI suggestions
  app.get("/api/ai/suggestions", authenticateToken, async (req: AuthRequest, res) => {
    try {
      const user = await storage.getUser(req.user!.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const recentTasks = await storage.getTasks({ assigneeId: (user as any)._id.toString() });
      const suggestions = await generateTaskSuggestions({
        recentTasks: recentTasks.slice(0, 5),
        userRole: user.role,
      });

      res.json({ suggestions });
    } catch (error) {
      res.status(500).json({ message: "Failed to get suggestions" });
    }
  });

  // Admin setup route - can be used once if no admin exists
  app.post("/api/admin/setup", authenticateToken, async (req: AuthRequest, res) => {
    try {
      // Check if any admin already exists
      const existingAdmins = await storage.getAllUsers();
      const hasAdmin = existingAdmins.some(user => user.role === 'admin');
      
      if (hasAdmin) {
        return res.status(400).json({ message: "Admin already exists" });
      }

      // Make current user admin
      const user = await storage.updateUser(req.user!.id, { role: 'admin' });
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      res.json({ 
        message: "Admin setup successful", 
        user: {
          id: (user as any)._id.toString(),
          email: user.email,
          firstName: user.firstName,
          lastName: user.lastName,
          role: user.role
        }
      });
    } catch (error) {
      console.error("Admin setup error:", error);
      res.status(500).json({ message: "Failed to setup admin" });
    }
  });

  // Cleanup expired OTP tokens periodically
  setInterval(async () => {
    try {
      await storage.cleanupExpiredTokens();
    } catch (error) {
      console.error("Cleanup error:", error);
    }
  }, 60 * 60 * 1000); // Every hour

  const httpServer = createServer(app);
  return httpServer;
}
