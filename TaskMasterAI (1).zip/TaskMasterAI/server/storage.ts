import { User, Task, Comment, Report, OTP, type IUser, type ITask, type IComment, type IReport, type IOTP, type InsertUser, type InsertTask, type InsertComment, type InsertReport, type InsertOTP } from "@shared/schema";
import mongoose from 'mongoose';
import { connectToDatabase } from './db';

export interface IStorage {
  // User methods
  getUser(id: string): Promise<IUser | undefined>;
  getUserByEmail(email: string): Promise<IUser | undefined>;
  createUser(user: InsertUser): Promise<IUser>;
  updateUser(id: string, updates: Partial<InsertUser>): Promise<IUser | undefined>;
  getAllUsers(): Promise<IUser[]>;
  getUsersByManager(managerId: string): Promise<IUser[]>;

  // Task methods
  getTask(id: string): Promise<(ITask & { creator: IUser; assignee: IUser }) | undefined>;
  getTasks(filters?: {
    assigneeId?: string;
    creatorId?: string;
    status?: string;
    priority?: string;
    dueBefore?: Date;
    dueAfter?: Date;
    managerId?: string;
  }): Promise<(ITask & { creator: IUser; assignee: IUser })[]>;
  createTask(task: InsertTask): Promise<ITask>;
  updateTask(id: string, updates: Partial<InsertTask>): Promise<ITask | undefined>;
  deleteTask(id: string): Promise<boolean>;
  getTasksByTeam(managerId: string): Promise<(ITask & { creator: IUser; assignee: IUser })[]>;

  // Comment methods
  getTaskComments(taskId: string): Promise<(IComment & { user: IUser })[]>;
  createComment(comment: InsertComment): Promise<IComment>;

  // Report methods
  createReport(report: InsertReport): Promise<IReport>;
  getUserReports(userId: string, limit?: number): Promise<IReport[]>;

  // OTP methods
  createOtpToken(token: InsertOTP): Promise<IOTP>;
  getValidOtpToken(email: string, token: string): Promise<IOTP | undefined>;
  markOtpTokenUsed(id: string): Promise<void>;
  cleanupExpiredTokens(): Promise<void>;

  // Analytics
  getTaskStats(userId?: string, managerId?: string): Promise<{
    total: number;
    inProgress: number;
    completed: number;
    overdue: number;
  }>;
}

export class MongoStorage implements IStorage {
  private async ensureConnection() {
    if (mongoose.connection.readyState !== 1) {
      console.log('MongoDB not connected, establishing connection...');
      await connectToDatabase();
    }
  }

  async getUser(id: string): Promise<IUser | undefined> {
    await this.ensureConnection();
    try {
      const user = await User.findById(id);
      return user || undefined;
    } catch (error) {
      console.error('Error getting user:', error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<IUser | undefined> {
    try {
      const user = await User.findOne({ email });
      return user || undefined;
    } catch (error) {
      console.error('Error getting user by email:', error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<IUser> {
    const user = new User({
      ...insertUser,
      managerId: insertUser.managerId ? new mongoose.Types.ObjectId(insertUser.managerId) : undefined
    });
    return await user.save();
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<IUser | undefined> {
    try {
      const updateData = {
        ...updates,
        managerId: updates.managerId ? new mongoose.Types.ObjectId(updates.managerId) : undefined,
        updatedAt: new Date()
      };
      const user = await User.findByIdAndUpdate(id, updateData, { new: true });
      return user || undefined;
    } catch (error) {
      console.error('Error updating user:', error);
      return undefined;
    }
  }

  async getAllUsers(): Promise<IUser[]> {
    return await User.find().sort({ firstName: 1, lastName: 1 });
  }

  async getUsersByManager(managerId: string): Promise<IUser[]> {
    return await User.find({ managerId: new mongoose.Types.ObjectId(managerId) });
  }

  async getTask(id: string): Promise<(ITask & { creator: IUser; assignee: IUser }) | undefined> {
    try {
      const task = await Task.findById(id)
        .populate('createdById', 'email username firstName lastName role')
        .populate('assigneeId', 'email username firstName lastName role');
      
      if (!task) return undefined;

      return {
        ...task.toObject(),
        creator: task.createdById as any,
        assignee: task.assigneeId as any
      } as any;
    } catch (error) {
      console.error('Error getting task:', error);
      return undefined;
    }
  }

  async getTasks(filters?: {
    assigneeId?: string;
    creatorId?: string;
    status?: string;
    priority?: string;
    dueBefore?: Date;
    dueAfter?: Date;
    managerId?: string;
  }): Promise<(ITask & { creator: IUser; assignee: IUser })[]> {
    try {
      let query: any = {};

      if (filters?.assigneeId) {
        query.assigneeId = new mongoose.Types.ObjectId(filters.assigneeId);
      }
      if (filters?.creatorId) {
        query.createdById = new mongoose.Types.ObjectId(filters.creatorId);
      }
      if (filters?.status) {
        query.status = filters.status;
      }
      if (filters?.priority) {
        query.priority = filters.priority;
      }
      if (filters?.dueBefore) {
        query.dueDate = { ...query.dueDate, $lte: filters.dueBefore };
      }
      if (filters?.dueAfter) {
        query.dueDate = { ...query.dueDate, $gte: filters.dueAfter };
      }
      if (filters?.managerId) {
        // Get tasks for all reportees of the manager
        const reportees = await this.getUsersByManager(filters.managerId);
        const reporteeIds = reportees.map(r => r._id);
        if (reporteeIds.length > 0) {
          query.assigneeId = { $in: reporteeIds };
        }
      }

      const tasks = await Task.find(query)
        .populate('createdById', 'email username firstName lastName role')
        .populate('assigneeId', 'email username firstName lastName role')
        .sort({ updatedAt: -1 });

      return tasks.map(task => ({
        ...task.toObject(),
        creator: task.createdById as any,
        assignee: task.assigneeId as any
      })) as any;
    } catch (error) {
      console.error('Error getting tasks:', error);
      return [];
    }
  }

  async createTask(task: InsertTask): Promise<ITask> {
    const newTask = new Task({
      ...task,
      assigneeId: new mongoose.Types.ObjectId(task.assigneeId),
      createdById: new mongoose.Types.ObjectId(task.createdById),
      dueDate: task.dueDate ? new Date(task.dueDate) : undefined
    });
    return await newTask.save();
  }

  async updateTask(id: string, updates: Partial<InsertTask>): Promise<ITask | undefined> {
    try {
      const updateData = {
        ...updates,
        assigneeId: updates.assigneeId ? new mongoose.Types.ObjectId(updates.assigneeId) : undefined,
        createdById: updates.createdById ? new mongoose.Types.ObjectId(updates.createdById) : undefined,
        dueDate: updates.dueDate ? new Date(updates.dueDate) : undefined,
        updatedAt: new Date()
      };
      
      // Remove undefined values
      Object.keys(updateData).forEach(key => {
        if ((updateData as any)[key] === undefined) {
          delete (updateData as any)[key];
        }
      });

      const task = await Task.findByIdAndUpdate(id, updateData, { new: true });
      return task || undefined;
    } catch (error) {
      console.error('Error updating task:', error);
      return undefined;
    }
  }

  async deleteTask(id: string): Promise<boolean> {
    try {
      const result = await Task.findByIdAndDelete(id);
      return !!result;
    } catch (error) {
      console.error('Error deleting task:', error);
      return false;
    }
  }

  async getTasksByTeam(managerId: string): Promise<(ITask & { creator: IUser; assignee: IUser })[]> {
    return await this.getTasks({ managerId });
  }

  async getTaskComments(taskId: string): Promise<(IComment & { user: IUser })[]> {
    try {
      const comments = await Comment.find({ taskId: new mongoose.Types.ObjectId(taskId) })
        .populate('userId', 'email username firstName lastName role')
        .sort({ createdAt: -1 });

      return comments.map(comment => ({
        ...comment.toObject(),
        user: comment.userId as any
      })) as any;
    } catch (error) {
      console.error('Error getting task comments:', error);
      return [];
    }
  }

  async createComment(comment: InsertComment): Promise<IComment> {
    const newComment = new Comment({
      ...comment,
      taskId: new mongoose.Types.ObjectId(comment.taskId),
      userId: new mongoose.Types.ObjectId(comment.userId)
    });
    return await newComment.save();
  }

  async createReport(report: InsertReport): Promise<IReport> {
    const newReport = new Report({
      ...report,
      generatedById: new mongoose.Types.ObjectId(report.generatedById)
    });
    return await newReport.save();
  }

  async getUserReports(userId: string, limit = 10): Promise<IReport[]> {
    return await Report.find({ generatedById: new mongoose.Types.ObjectId(userId) })
      .sort({ createdAt: -1 })
      .limit(limit);
  }

  async createOtpToken(token: InsertOTP): Promise<IOTP> {
    await this.ensureConnection();
    const newToken = new OTP({
      ...token,
      expiresAt: new Date(token.expiresAt)
    });
    return await newToken.save();
  }

  async getValidOtpToken(email: string, token: string): Promise<IOTP | undefined> {
    try {
      const otpToken = await OTP.findOne({
        email,
        code: token,
        used: false,
        expiresAt: { $gte: new Date() }
      });
      return otpToken || undefined;
    } catch (error) {
      console.error('Error getting valid OTP token:', error);
      return undefined;
    }
  }

  async markOtpTokenUsed(id: string): Promise<void> {
    await OTP.findByIdAndUpdate(id, { used: true });
  }

  async cleanupExpiredTokens(): Promise<void> {
    await OTP.deleteMany({ expiresAt: { $lte: new Date() } });
  }

  async getTaskStats(userId?: string, managerId?: string): Promise<{
    total: number;
    inProgress: number;
    completed: number;
    overdue: number;
  }> {
    try {
      let query: any = {};

      if (userId) {
        query.assigneeId = new mongoose.Types.ObjectId(userId);
      }

      if (managerId) {
        const reportees = await this.getUsersByManager(managerId);
        const reporteeIds = reportees.map(r => r._id);
        if (reporteeIds.length > 0) {
          query.assigneeId = { $in: reporteeIds };
        }
      }

      const allTasks = await Task.find(query);
      const now = new Date();

      const stats = {
        total: allTasks.length,
        inProgress: allTasks.filter(t => t.status === 'in_progress').length,
        completed: allTasks.filter(t => t.status === 'done').length,
        overdue: allTasks.filter(t => t.dueDate && new Date(t.dueDate) < now && t.status !== 'done').length,
      };

      return stats;
    } catch (error) {
      console.error('Error getting task stats:', error);
      return { total: 0, inProgress: 0, completed: 0, overdue: 0 };
    }
  }
}

export const storage = new MongoStorage();